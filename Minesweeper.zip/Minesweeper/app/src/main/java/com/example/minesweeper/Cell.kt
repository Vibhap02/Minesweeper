package com.example.minesweeper

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.core.content.ContextCompat

class Cell(context: Context?, x: Int, y: Int) : BaseCell(context), View.OnClickListener,View.OnLongClickListener {


    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, widthMeasureSpec)
    }
    // Function to reveal cells when clicked
    override fun onClick(v: View?) {

        GameEngine.getInstance()?.click(getXPos(), getYPos())

    }
    // Function to use Flag when long Clicked
    override fun onLongClick(v: View?): Boolean {
        GameEngine.getInstance()?.flag(getXPos(), getYPos())

        return true
    }
    // Function to draw different images on respective cells
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        Log.d("Minesweeper", "Cell::onDraw")
        drawButton(canvas)
        if (isFlagged() && !isRevealed()) {
            drawFlag(canvas)//Draw flag

        } else if (isRevealed() && isBomb() && !isClicked()) {
            drawNormalBomb(canvas)// Draw Normal Bomb

        } else {
            if (isClicked()) {
                if (getValue() == -1) {
                    drawBombExploded(canvas)// Draw bomb when exploded
                } else {
                    drawNumber(canvas)// To reveal numbers
                }

            } else {
                drawButton(canvas)
            }
        }
    }

    private fun drawBombExploded(canvas: Canvas) {
        val drawable = ContextCompat.getDrawable(context, R.drawable.bombexploded)
        drawable!!.setBounds(0, 0, width, height)
        drawable.draw(canvas)

    }

    private fun drawFlag(canvas: Canvas) {
        val drawable = ContextCompat.getDrawable(context, R.drawable.flag)
        drawable!!.setBounds(0, 0, width, height)
        drawable.draw(canvas)
    }

    private fun drawButton(canvas: Canvas) {
        val drawable = ContextCompat.getDrawable(context, R.drawable.button)
        drawable!!.setBounds(0, 0, width, height)
        drawable.draw(canvas)
    }

    private fun drawNormalBomb(canvas: Canvas) {
        val drawable = ContextCompat.getDrawable(context, R.drawable.bomb_normal)
        drawable!!.setBounds(0, 0, width, height)
        drawable.draw(canvas)
    }

    private fun drawNumber(canvas: Canvas) {
        var drawable: Drawable? = null
        when (getValue()) {
            0 -> drawable = ContextCompat.getDrawable(context, R.drawable.number_0)
            1 -> drawable = ContextCompat.getDrawable(context, R.drawable.number1)
            2 -> drawable = ContextCompat.getDrawable(context, R.drawable.number_2)
            3 -> drawable = ContextCompat.getDrawable(context, R.drawable.number_3)
            4 -> drawable = ContextCompat.getDrawable(context, R.drawable.number_4)
            5 -> drawable = ContextCompat.getDrawable(context, R.drawable.number_5)
            6 -> drawable = ContextCompat.getDrawable(context, R.drawable.number_6)
            7 -> drawable = ContextCompat.getDrawable(context, R.drawable.number_7)
            8 -> drawable = ContextCompat.getDrawable(context, R.drawable.number_8)
        }
        drawable!!.setBounds(0, 0, width, height)
        drawable.draw(canvas)
    }

    init {
        setPosition(x, y)
        setOnClickListener(this)
        setOnLongClickListener(this)
    }
}
