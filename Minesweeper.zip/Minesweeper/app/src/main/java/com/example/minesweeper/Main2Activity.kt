package com.example.minesweeper

import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Chronometer
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.mines.*

//game page.
class Main2Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.mines)

        val meter = findViewById<Chronometer>(R.id.meter)

        meter.start()// to start chronometer
        var ch:Boolean=true
    val stop = findViewById<Button>(R.id.stop)
    stop.setOnClickListener {
        ch=false
        meter.stop()
        val elapsedMillis: Long = SystemClock.elapsedRealtime() - meter.base  // to extract time
        var sec = elapsedMillis
        var min = elapsedMillis
        val unit1 = "min"
        val unit2 = "sec"
        if (elapsedMillis < 60000) {
            sec = (elapsedMillis / 1000)
            min = 0
        }
        if (elapsedMillis in 60000..3599999) {
            min = (elapsedMillis / 60000)
            val t = min * 60000
            val lt = elapsedMillis - t
            sec = (lt / 1000)
        }
        Toast.makeText(this, "Time Taken: $min $unit1 $sec $unit2", Toast.LENGTH_SHORT).show()
        }


        val setagain: Button = findViewById(R.id.setagain)// to go to home page.

        setagain.setOnClickListener {

            if (ch){
            val elapsedMillis: Long =SystemClock.elapsedRealtime() - meter.base   // to extract time
            var sec=elapsedMillis
            var min=elapsedMillis
            val unit1="min"
            val unit2="sec"
            if(elapsedMillis<60000){
                sec= (elapsedMillis/1000)
                min=0


            }
            if(elapsedMillis in 60000..3599999) {
                min=(elapsedMillis/60000)
                val t = min*60000
                val lt= elapsedMillis-t
                sec= (lt/1000)

            }
            Toast.makeText(this, "Time Taken: $min $unit1 $sec $unit2",Toast.LENGTH_SHORT).show()}

            val intent1 = Intent(this, MainActivity::class.java)

            startActivity(intent1)

        }
        val restart: Button = findViewById(R.id.restart)//to restrt the game.
        restart.setOnClickListener {
            if(ch) {
                val elapsedMillis: Long =
                    SystemClock.elapsedRealtime() - meter.base  // to extract time
                var sec = elapsedMillis
                var min = elapsedMillis
                val unit1 = "min"
                val unit2 = "sec"
                if (elapsedMillis < 60000) {
                    sec = (elapsedMillis / 1000)
                    min = 0


                }
                if (elapsedMillis in 60000..3599999) {
                    min = (elapsedMillis / 60000)
                    val t = min * 60000
                    val lt = elapsedMillis - t
                    sec = (lt / 1000)

                }
                Toast.makeText(this, "Time Taken: $min $unit1 $sec $unit2", Toast.LENGTH_SHORT)
                    .show()
            }

            val intent1 = Intent(this, Main2Activity::class.java)
            startActivity(intent1)
        }
        Log.e("MainActivity", "onCreate");
        GameEngine.getInstance()?.createGrid(this)// main code of the game
    }
    // to go to home page by a back click.
    override fun onBackPressed() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}