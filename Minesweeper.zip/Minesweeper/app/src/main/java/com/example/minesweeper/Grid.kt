package com.example.minesweeper

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup

import android.widget.BaseAdapter

import android.widget.GridView


class Grid(context: Context?, attrs: AttributeSet?) : GridView(context, attrs) {


    private inner class GridAdapter : BaseAdapter() {
        // Function to get count
        override fun getCount(): Int {

            return (GameEngine.getInstance()?.WIDTH!!).times((GameEngine.getInstance()?.HEIGHT!!))
        }
        // Function to get item
        override fun getItem(position: Int): Any? {
            return null
        }
        // Function to get item ID
        override fun getItemId(position: Int): Long {
            return 0
        }
        // Function to Getview
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): Cell? {
            return GameEngine.getInstance()?.getCellAt(position)
        }
    }

    init {

        GameEngine.getInstance()?.createGrid(context)
        numColumns = GameEngine.WIDTH
        adapter = GridAdapter()
    }
}