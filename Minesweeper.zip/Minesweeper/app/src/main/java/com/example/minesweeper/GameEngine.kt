package com.example.minesweeper

import android.content.Context
import android.util.Log
import android.widget.Toast

class GameEngine{
        //to specify the dimensions of grid
        val WIDTH = 12
        val HEIGHT = 12
        var BOMB_NUMBER =20

        private var context: Context? = null
        private val MinesweeperGrid: Array<Array<Cell?>> =
            Array<Array<Cell?>>(WIDTH) { arrayOfNulls<Cell>(HEIGHT) }
        // To create the grid
        fun createGrid(context: Context?) {
            Log.e("GameEngine", "createGrid is working")//for errors.
            this.context = context
            val GeneratedGrid: Array<IntArray> = Generator.generate(BOMB_NUMBER, WIDTH, HEIGHT)//to generate the grid.
            PrintGrid.print(GeneratedGrid, WIDTH, HEIGHT)//to print the grid.
            if (context != null) {
                setGrid(context, GeneratedGrid)
            }
        }
        //to set grid.
        private fun setGrid(context: Context, grid: Array<IntArray>) {
            for (x in 0 until WIDTH) {
                for (y in 0 until HEIGHT) {
                    if (MinesweeperGrid[x][y] == null) {
                        MinesweeperGrid[x][y] = Cell(context, x, y)
                    }
                    MinesweeperGrid[x][y]?.setValue(grid[x][y])
                    MinesweeperGrid[x][y]?.invalidate()
                    getCellAt(x, y)?.isEnabled = true


                }
            }
        }
        //To get the position of a cell
        fun getCellAt(position: Int): Cell? {
            val x = position % WIDTH
            val y = position / WIDTH
            return MinesweeperGrid[x][y]
        }
        private fun getCellAt(x: Int, y: Int): Cell? {
            return MinesweeperGrid[x][y]
        }
        // Trigger a cell when it is clicked by user
        fun click(x: Int, y: Int) {
            if (x >= 0 && y >= 0 && x < WIDTH && y < HEIGHT && !getCellAt(x, y)?.isClicked()!!) {
                getCellAt(x, y)?.setClicked()
                if (getCellAt(x, y)?.getValue() ?: 0 == 0) {
                    for (xt in -1..1) {
                        for (yt in -1..1) {
                            if (xt != yt) {
                                click(x + xt, y + yt)
                            }
                        }
                    }
                }
                if (getCellAt(x, y)?.isBomb()!!) {
                    onGameLost()
                }
            }
            checkEnd()
        }
    // To check whether a user has won or lost after the game is completed
        private fun checkEnd(): Boolean {


            var bombNotFound = BOMB_NUMBER
            var notRevealed = WIDTH * HEIGHT



            for (x in 0 until WIDTH) {
                for (y in 0 until HEIGHT) {
                    if (getCellAt(x, y)?.isRevealed() != false || getCellAt(x,y)?.isFlagged() != false) {
                        notRevealed--
                    }
                    if (getCellAt(x, y)?.isFlagged() != false && getCellAt(x,y)?.isBomb() != false) {
                        bombNotFound--
                    }
                }
            }
            if (bombNotFound == 0 && notRevealed == 0) {
                Toast.makeText(context, "Game won", Toast.LENGTH_SHORT).show()// User has WON
            }
            return false
        }
        // To set Flags at specified cells by the user
        fun flag(x: Int, y: Int) {
                val isFlagged: Boolean = getCellAt(x, y)?.isFlagged()!!
                getCellAt(x, y)?.setFlagged(!isFlagged)
                getCellAt(x, y)?.invalidate()
            }


        // To reveal all bombs when game is LOST.
        private fun onGameLost(){

            Toast.makeText(context, "Better Luck Next Time", Toast.LENGTH_SHORT).show()
            for (x in 0 until WIDTH) {
                for (y in 0 until HEIGHT) {
                    getCellAt(x, y)?.setRevealed()
                    getCellAt(x, y)?.isEnabled = false
                }
            }
        }

        companion object {
            const val WIDTH = 12
            //To create instance of Game Engine.
            private var instance: GameEngine? = null
            fun getInstance(): GameEngine? {
                if (instance == null) {
                    instance = GameEngine()
                }
                return instance
            }
        }
    }

