package com.example.minesweeper

import android.content.Context
import android.view.View


abstract class BaseCell(context: Context?) : View(context) {
    private var value:Int = 0
    private var x:Int = 0
    private var isBomb:Boolean = false
    private var isRevealed:Boolean  = false
    private var isClicked:Boolean  = false
    private var isFlagged:Boolean  = false
    private  var y:Int = 0
    private var position:Int = 0
    // To get Value
    open fun getValue(): Int {
        return value

    }
    // To set value
    open fun setValue(value: Int) {

        isBomb = false
        isRevealed = false
        isClicked = false
        isFlagged = false
        if (value == -1) {
            isBomb = true
        }
        this.value = value
    }
    // To check whether the cell is a bomb.
    open fun isBomb(): Boolean {
        return isBomb
    }
    // To set a bomb.
    open fun setBomb(bomb: Boolean) {
        isBomb = bomb
    }
    // To check whether the cell is revealed.

    open fun isRevealed(): Boolean {
        return isRevealed
    }
    // To reveal a cell
    open fun setRevealed() {
        isRevealed = true
        invalidate()
    }
    // To check whether the cell is clicked.
    open fun isClicked(): Boolean {
        return isClicked
    }
    // To click a cell
    open fun setClicked() {
        this.isClicked = true
        this.isRevealed = true
        invalidate()
    }
    //To check whether the cell is flagged.
    open fun isFlagged(): Boolean {
        return isFlagged
    }
    //To Flag a cell
    open fun setFlagged(flagged: Boolean) {
        isFlagged = flagged
    }
    // To get the position of row
    open fun getXPos(): Int {
        return x
    }
    // To get the position of Columns
    open fun getYPos(): Int {
        return y
    }
    // To get the position of Cell
    open fun getPosition(): Int {
        return position
    }
    // To set a specific position
    open fun setPosition(x: Int, y: Int) {
        this.x = x
        this.y = y
        this.position = y * GameEngine.WIDTH + x
        invalidate()
    }

}