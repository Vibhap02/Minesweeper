package com.example.minesweeper

import android.util.Log


object PrintGrid {
    // To print the minesweeper Grid
    fun print(grid: Array<IntArray>, width: Int, height: Int) {
        for (x in 0 until width) {
            var printedText = "| "
            for (y in 0 until height) {
                printedText += grid[x][y].toString().replace("-1", "B") + " | "
            }
            Log.e("", printedText)
        }
    }
}